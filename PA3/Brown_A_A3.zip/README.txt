1.  a. Annika Brown
    b. 2428684
    c. annbrown@chapman.edu
    d. CPSC350
    e. PA3
2. MonoStack.h SpeakerView.h SpeakerView.cpp main.cpp
3. None
4. None
5. just compile and run the code with input file as argument:
    g++ *.cpp
    ./a.out input.txt