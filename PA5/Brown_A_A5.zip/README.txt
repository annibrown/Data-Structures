1.  a. Annika Brown
    b. 2428684
    c. annbrown@chapman.edu
    d. CPSC350
    e. PA5
2. DblList.h ListNode.h LazyBST.h TreeNode.h Student.h Student.cpp Faculty.h Faculty.cpp main.cpp
3. None
4.  https://www.techiedelight.com/string-representation-of-object-cpp/
    https://www.geeksforgeeks.org/how-to-get-element-at-specific-position-in-list-in-c/
    https://stackoverflow.com/questions/22269435/how-to-iterate-through-a-list-of-objects-in-c

5. just compile and run the code with input file as argument:
    g++ *.cpp
    ./a.out