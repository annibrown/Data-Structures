1.  a. Annika Brown
    b. 2428684
    c. annbrown@chapman.edu
    d. CPSC350
    e. PA2
2. Input.h Input.cpp Levels.h Levels.cpp Mario.h Mario.cpp main.cpp
3. None
4. None
5. just compile and run the code with input and output files as arguments:
    g++ *.cpp
    ./a.out in.txt out.txt