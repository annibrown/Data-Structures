1.  a. Annika Brown
    b. 2428684
    c. annbrown@chapman.edu
    d. CPSC350
    e. PA1
2. Model.h Model.cpp Translator.h Translator.cpp FileProcessor.h FileProcessor.cpp main.cpp
3. None
4. None
5. just compile and run the code:
    g++ Model.h Model.cpp Translator.h Translator.cpp FileProcessor.h FileProcessor.cpp main.cpp -o robber.exe
    ./robber.exe