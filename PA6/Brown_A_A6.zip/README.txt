1.  a. Annika Brown
    b. 2428684
    c. annbrown@chapman.edu
    d. CPSC350
    e. PA6
2. DblList.h ListNode.h Edge.h Edge.cpp PQueue.h WGraph.cpp WGraph.h main.cpp
3. None
4. None
5. just compile and run the code with input file as argument:
    g++ *.cpp input.txt
    ./a.out